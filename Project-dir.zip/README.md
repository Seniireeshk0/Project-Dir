# Antigravity Project Workspace Manager

> Global workspace & project organizer for Google Antigravity. Automatically isolates every coding task into its own structured project directory under a customizable root folder.

---

## 🚀 Overview

By default, agentic assistants often scatter generated files across temporary scratchpads or arbitrary system folders. **Antigravity Project Workspace Manager** solves this problem permanently by:

1. **Centralizing Workspace Roots**: Setting a dedicated root directory (e.g., `C:\Antigravity` or `D:\Projects`) where all Antigravity creations live.
2. **Strict Project Isolation**: Every distinct task, app, or experiment automatically gets its own structured subfolder (`src/`, `docs/`, `scripts/`, `README.md`).
3. **Interactive Control (`/project-dir`)**: Built-in slash command to inspect current paths, switch directories, or open a native Windows folder browser dialog with one click.
4. **Cross-Platform CLI Utilities**: Includes PowerShell (`workspace_tool.ps1`) and Python (`workspace_tool.py`) command-line tools for headless or scriptable environments.

---

## 📦 Directory Structure

```text
project-workspace-manager/
├── plugin.json                 # Antigravity plugin manifest
├── README.md                   # Documentation & guide
├── rules/
│   └── AGENTS.md               # Global agent enforcement rules
├── skills/
│   ├── project-dir/
│   │   └── SKILL.md            # /project-dir slash command handler
│   └── workspace-manager/
│       └── SKILL.md            # Full workspace management procedures
└── scripts/
    ├── workspace_tool.ps1      # PowerShell tool with Windows GUI picker
    └── workspace_tool.py       # Python CLI utility
```

---

## ⚡ Slash Command: `/project-dir`

Type `/project-dir` in your Antigravity chat to:
- Check your current active root folder.
- List all existing project subdirectories.
- Switch the active root folder or launch the Windows GUI folder picker.
- Scaffold a new project with standard boilerplate.

---

## 🛠️ CLI Usage

You can also run the utility directly from your terminal:

### PowerShell
```powershell
# Open native Windows visual folder picker dialog
powershell -ExecutionPolicy Bypass -File "scripts/workspace_tool.ps1" -PickGui

# Change the project root directory
powershell -ExecutionPolicy Bypass -File "scripts/workspace_tool.ps1" -SetRoot "C:\Antigravity"

# List all projects
powershell -ExecutionPolicy Bypass -File "scripts/workspace_tool.ps1" -ListProjects

# Scaffold a new project folder
powershell -ExecutionPolicy Bypass -File "scripts/workspace_tool.ps1" -NewProject "my-awesome-app" -Description "My new project"
```

### Python
```bash
# Print active projects root
python scripts/workspace_tool.py --get-root

# Set root directory
python scripts/workspace_tool.py --set-root "C:\Antigravity"

# List projects
python scripts/workspace_tool.py --list-projects

# Scaffold a new project
python scripts/workspace_tool.py --new-project "my-awesome-app" --desc "My new project"
```

---

## 📥 Installation

1. Copy or extract this repository into your global Antigravity plugins directory:
   ```text
   C:\Users\<YourUser>\.gemini\config\plugins\project-workspace-manager\
   ```
2. Enable it in your `~/.gemini/config/config.json`:
   ```json
   {
     "plugins": {
       "project-workspace-manager": {
         "enabled": true
       }
     }
   }
   ```
3. Type `/project-dir` in Antigravity to verify installation!

---

## 📄 License
MIT License. Free to use, modify, and distribute.
