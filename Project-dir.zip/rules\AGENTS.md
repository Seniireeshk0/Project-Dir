# Global Project Workspace & Organization Rules

These rules govern how files, projects, and deliverables are structured across all sessions in Antigravity:

## 1. Centralized Projects Root
- All projects, coding tasks, applications, and tools created by Antigravity MUST be placed inside the configured projects root directory:
  - Settings file: `C:\Users\arsen\.gemini\config\workspace_settings.json`
  - Field: `projects_root` (e.g. `D:\Projects` or `C:\Users\arsen\Projects`).
- If `workspace_settings.json` does not exist or `projects_root` is unset, default to `D:\Projects` (or `C:\Users\arsen\Projects` if D: is unavailable) and inform the user.
- If the user asks to change, choose, or pick the root directory, update `workspace_settings.json` or run `C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1 -PickGui` (or `-SetRoot <path>`).

## 2. Dedicated Folder per Project (No Clutter)
- **Every project gets its own directory**: Never dump files directly into the root directory, user home, desktop, or generic scratchpad (`.gemini\antigravity\scratch`) unless the user explicitly requested a temporary one-off scratch script.
- Project folder path format: `<projects_root>/<project-name>/`.
- Inside each project directory, group files systematically:
  - Code & modules: `src/` or top-level package folder
  - Documentation: `docs/` or `README.md`
  - Tests: `tests/`
  - Scripts: `scripts/`
  - Assets/data: `assets/` or `data/`

## 3. Transparency & Workspace Integration
- When creating a new project folder, output clickable markdown file links (`[Project Folder](file:///...)`).
- Prompt or recommend that the user set this directory as their active workspace in Antigravity or their code editor.
