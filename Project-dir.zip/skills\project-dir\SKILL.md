---
name: project-dir
description: View, choose, or change the Antigravity projects root folder, open the folder selection dialog, or list all project subdirectories. Triggered by the /project-dir slash command.
---

# Project Directory Manager (`/project-dir`)

Use this skill whenever the user calls `/project-dir` or asks to view, select, configure, or change the Antigravity projects root directory.

## Current Configuration
- Root setting: `projects_root` in `C:\Users\arsen\.gemini\config\workspace_settings.json`
- Default / active directory: `C:\Antigravity`
- Management script: `C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1`

## Workflow on `/project-dir` Invocation:

1. **Check Current Status**:
   Read `C:\Users\arsen\.gemini\config\workspace_settings.json` and display the current active root folder with a clickable link (`[C:\Antigravity](file:///C:/Antigravity)`).

2. **Offer Immediate Options** via `ask_question`:
   - Keep current directory (`C:\Antigravity`)
   - Pick a new folder visually using the Windows folder dialog (`-PickGui`)
   - Enter a custom folder path manually
   - List all project folders in current root

3. **Actions Execution**:
   - **Launch GUI Folder Picker**:
     ```powershell
     powershell -ExecutionPolicy Bypass -File "C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1" -PickGui
     ```
   - **Set Direct Path**:
     ```powershell
     powershell -ExecutionPolicy Bypass -File "C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1" -SetRoot "<Path>"
     ```
   - **List Projects**:
     ```powershell
     powershell -ExecutionPolicy Bypass -File "C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1" -ListProjects
     ```
   - **Create New Project Subdirectory**:
     ```powershell
     powershell -ExecutionPolicy Bypass -File "C:\Users\arsen\.gemini\config\plugins\project-workspace-manager\scripts\workspace_tool.ps1" -NewProject "<ProjectName>"
     ```
